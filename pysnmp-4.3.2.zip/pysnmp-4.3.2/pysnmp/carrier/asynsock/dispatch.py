#
# This file is part of pysnmp software.
#
# Copyright (c) 2005-2016, Ilya Etingof <ilya@glas.net>
# License: http://pysnmp.sf.net/license.html
#
from pysnmp.carrier.asyncore.dispatch import *

AsynsockDispatcher = AsyncoreDispatcher
